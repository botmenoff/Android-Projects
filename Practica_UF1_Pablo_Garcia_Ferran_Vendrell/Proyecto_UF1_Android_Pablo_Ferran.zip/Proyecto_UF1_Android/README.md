Esto es un proyecto de una aplicación de peliculas para ver informacion de tus pelis favotritas y para la asignatura de Android =)
