package com.example.android_project.Models

enum class Idiomas(val nombre: String) {
    ESP("Español"),
    ENG("Inglés"),
    FRA("Francés"),
    ITA("Italiano"),
    RUS("Ruso");

    override fun toString(): String {
        return "$nombre\n"
    }
}